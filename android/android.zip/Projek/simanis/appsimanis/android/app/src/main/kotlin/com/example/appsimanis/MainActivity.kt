package com.example.appsimanis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
