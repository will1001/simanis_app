import 'dart:async';
import 'dart:convert';

import 'package:appsimanis/Model/CRUD.dart';
import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:appsimanis/Services/FunctionGroup.dart';
import 'package:appsimanis/Widget/Button1.dart';
import 'package:appsimanis/Widget/DropDownString.dart';
import 'package:appsimanis/Widget/GradientBg.dart';
import 'package:appsimanis/Widget/InputForm.dart';
import 'package:appsimanis/Widget/PanelPopUp.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

class Daftar extends StatefulWidget {
  const Daftar({Key? key}) : super(key: key);

  @override
  _DaftarState createState() => _DaftarState();
}

class _DaftarState extends State<Daftar> {
  FunctionGroup functionGroup = new FunctionGroup();
  // late Position position;
  CRUD crud = new CRUD();
  final _formKey = GlobalKey<FormState>();
  Completer<GoogleMapController> _controller = Completer();
  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  List<Marker> allMarkers = [];
  bool _showPopUp = false;
  String _message = "";
  String _provinsi = "52";
  String _kabupaten = "";
  String _kecamatan = "";
  String _kelurahan = "";
  String _lat = "";
  String _lng = "";
  List _listProvinsi = [
    {'id': '52', 'name': 'Nusa Tenggara Barat'}
  ];
  List _listKabupaten = [];
  List _listKecamatan = [];
  List _listKelurahan = [];
  TextEditingController _namaPemilikController = new TextEditingController();
  TextEditingController _namaPerusahaanController = new TextEditingController();
  TextEditingController _nikController = new TextEditingController();
  TextEditingController _alamatController = new TextEditingController();
  TextEditingController _nomorTelponController = new TextEditingController();
  TextEditingController _emailController = new TextEditingController();
  TextEditingController _passwordController = new TextEditingController();
  TextEditingController _confirmPasswordController =
      new TextEditingController();
  TextEditingController _latController = new TextEditingController();
  TextEditingController _lngController = new TextEditingController();

  getAlamat() async {
    // LocationPermission permission = await Geolocator.requestPermission();
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    List<Placemark> placemarks =
        await placemarkFromCoordinates(position.latitude, position.longitude);
    CameraPosition _currentPosition = CameraPosition(
        bearing: 0,
        target: LatLng(position.latitude, position.longitude),
        tilt: 0,
        zoom: 16.5);

    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(_currentPosition));
    String alamat = placemarks[0].street.toString() +
        " " +
        placemarks[0].subLocality.toString() +
        " " +
        placemarks[0].locality.toString() +
        " " +
        placemarks[0].subAdministrativeArea.toString() +
        " " +
        placemarks[0].administrativeArea.toString();
    setState(() {
      _alamatController.text = alamat;
      _latController.text = position.latitude.toString();
      _lngController.text = position.longitude.toString();
      // String _getkabupaten =
      //     placemarks[0].subAdministrativeArea.toString().toUpperCase();
      // String _getkecamatan = placemarks[0].locality.toString().toUpperCase();
      // String _getkelurahan = placemarks[0].subLocality.toString().toUpperCase();
      // _listKabupaten.add(_getkabupaten);
      // _listKecamatan.add(_getkecamatan);
      // _listKelurahan.add(_getkelurahan);
      // _kabupaten = _getkabupaten;
      // _kecamatan = _getkecamatan;
      // _kelurahan = _getkelurahan;
      allMarkers.add(Marker(
          markerId: MarkerId("marker1"),
          draggable: false,
          onTap: () {},
          position: LatLng(position.latitude, position.longitude)));
    });
    // print(placemarks);
  }

  @override
  void initState() {
    super.initState();
    crud.getData("/provinsi/52/kabupaten").then((data) {
      // print(jsonDecode(data.body));
      setState(() {
        _listKabupaten = jsonDecode(data.body);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
            )),
        centerTitle: true,
        title: Text(
          "Daftar",
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Stack(
            children: [
              gradientBg(),
              SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      inputForm(null, "Nama Pemilik", "text", "Nama Pemilik",
                          "Tidak Boleh Kosong", _namaPemilikController, false),
                      inputForm(
                          null,
                          "Nama Perusahaan",
                          "text",
                          "Nama Perusahaan",
                          "Tidak Boleh Kosong",
                          _namaPerusahaanController,
                          false),
                      inputForm(null, "NIK", "number", "NIK",
                          "Tidak Boleh Kosong", _nikController, false),
                      dropDownString(_provinsi, 'Provinsi', _listProvinsi,
                          (newValue) {
                        setState(() {
                          _provinsi = newValue!;
                        });
                      }),
                      dropDownString(_kabupaten, 'Kabupaten', _listKabupaten,
                          (newValue) {
                        crud
                            .getData("/kabupaten/" + newValue + "/kecamatan")
                            .then((data) {
                          setState(() {
                            _kecamatan = "";
                            _kelurahan = "";
                            _listKecamatan.clear();
                            _listKelurahan.clear();
                            _listKecamatan = jsonDecode(data.body);
                            _kabupaten = newValue;
                          });
                        });
                      }),
                      // Text(_listKabupaten[0].toString()),
                      dropDownString(_kecamatan, 'Kecamatan', _listKecamatan,
                          (newValue) {
                        crud
                            .getData("/kecamatan/" + newValue + "/kelurahan")
                            .then((data) {
                          setState(() {
                            _kelurahan = "";
                            _listKelurahan.clear();
                            _listKelurahan = jsonDecode(data.body);
                            _kecamatan = newValue;
                          });
                        });
                      }),
                      dropDownString(_kelurahan, 'Kelurahan', _listKelurahan,
                          (newValue) {
                        setState(() {
                          _kelurahan = newValue;
                        });
                      }),
                      inputForm(null, "Alamat", "text", "Alamat",
                          "Tidak Boleh Kosong", _alamatController, false),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 5),
                        child: Container(
                          height: 200,
                          width: MediaQuery.of(context).size.width,
                          child: GoogleMap(
                            markers: Set.from(allMarkers),
                            mapType: MapType.normal,
                            initialCameraPosition: _kGooglePlex,
                            onMapCreated: (GoogleMapController controller) {
                              _controller.complete(controller);
                            },
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Container(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: () {
                              getAlamat();
                            },
                            icon: Icon(Icons.place),
                            label: Text("Cari Lokasi"),
                            style: ElevatedButton.styleFrom(
                                primary: themeProvider.buttonColor,
                                padding: EdgeInsets.symmetric(vertical: 10)),
                          ),
                        ),
                      ),
                      inputForm(null, "Latitude", "text", "Latitude",
                          "Tidak Boleh Kosong", _latController, false),
                      inputForm(null, "Longitude", "text", "Longitude",
                          "Tidak Boleh Kosong", _lngController, false),
                      inputForm(null, "Nomor Telpon", "number", "Nomor Telpon",
                          "Tidak Boleh Kosong", _nomorTelponController, false),
                      inputForm(null, "Email", "text", "Email",
                          "Tidak Boleh Kosong", _emailController, false),
                      inputForm(null, "Password", "text", "Password",
                          "Tidak Boleh Kosong", _passwordController, true),
                      inputForm(
                          null,
                          "Confirm Password",
                          "text",
                          "Confirm Password",
                          "Tidak Boleh Kosong",
                          _confirmPasswordController,
                          true),
                      Container(
                        width: double.infinity,
                        child: button1(
                            "Daftar", themeProvider.buttonColor, context, () {
                          if (_formKey.currentState!.validate()) {
                            Map<String, String> dataUsers = {
                              "nama": _namaPemilikController.text,
                              "nama_perusahaan": _namaPerusahaanController.text,
                              "nik": _nikController.text,
                              "id_provinsi": _provinsi,
                              "id_kabupaten": _kabupaten,
                              "id_kecamatan": _kecamatan,
                              "id_kelurahan": _kelurahan,
                              "lat": _lat,
                              "lng": _lng,
                              "alamat": _alamatController.text,
                              "nomor_telpon": _nomorTelponController.text,
                              "tipe_user": "Pengusaha",
                              "email": _emailController.text,
                              "password": _passwordController.text,
                            };

                            Map<String, String> checkData = {
                              "email": _emailController.text,
                              "password": _passwordController.text,
                            };

                            crud.checkLogin(checkData).then((res) {
                              var data = jsonDecode(res.body);
                              print(data['message']);
                              if (data['message'] == 'data ada' ||
                                  data['message'] == 'Password Salah') {
                                setState(() {
                                  _showPopUp = true;
                                  _message = "Email sudah Terdaftar";
                                });
                              } else {
                                crud.postData("/users", dataUsers).then((res) {
                                  if (res.statusCode == 201) {
                                    functionGroup.saveCache(dataUsers);
                                    Navigator.pushNamed(
                                        context, '/homeLayoutPage',
                                        arguments: <String, dynamic>{
                                          "selectedIndex": 3
                                        });
                                  } else {
                                    print("error");
                                  }
                                });
                              }
                            });
                          }
                        }),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          _showPopUp
              ? panelPopUp(context, _message, () {}, () {
                  setState(() {
                    _showPopUp = false;
                  });
                })
              : Container()
        ],
      ),
    );
  }
}
