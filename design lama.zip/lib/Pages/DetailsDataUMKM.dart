import 'dart:async';

import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/FilterButton.dart';
import 'package:appsimanis/Widget/ListLabel2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class DetailsDataUMKM extends StatefulWidget {
  const DetailsDataUMKM({Key? key}) : super(key: key);

  @override
  _DetailsDataUMKMState createState() => _DetailsDataUMKMState();
}

class _DetailsDataUMKMState extends State<DetailsDataUMKM> {
  var args;
  List<Marker> allMarkers = [];
  Completer<GoogleMapController> _controller = Completer();
  var _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  String _storageUrl = "https://simanis.ntbprov.go.id/storage/";
  // var _kGooglePlex;
  String _foto = "Alat";

  // initialMap()async{
  //   CameraPosition _kGooglePlex = CameraPosition(
  //   target: LatLng(37.42796133580664, -122.085749655962),
  //   zoom: 14.4746,
  // );
  // }

  convertIdCabangIndustri(String? _idCabangIndustri) {
    String result = "";
    switch (_idCabangIndustri) {
      case "006c4210-7806-11eb-9b1b-81d2fad81425":
        result = "Pangan";
        break;
      case "006d2610-7806-11eb-ab4c-a1abd6abcd37":
        result = "Hulu Agro";
        break;
      case "006d8f20-7806-11eb-9444-bd238317ed47":
        result = "Permesinan, Alat Transportasi & Energi Terbarukan";
        break;
      case "006e3bd0-7806-11eb-a766-e1c38c7e931e":
        result = "Hasil Pertambangan";
        break;
      case "006f3b70-7806-11eb-ae50-d1725dc37289":
        result = "Ekonomi Kreatif";
        break;
      case "006eb850-7806-11eb-87a5-6fa3dfe46649":
        result = "Kimia , Farmasi, Kosmetik & Kesehatan";
        break;
      default:
        result = "";
    }
    return result;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      var arguments = (ModalRoute.of(context)!.settings.arguments as Map);
      setState(() {
        args = arguments;
      });
      if (arguments["lat"] != null && arguments["lng"] != null) {
        setState(() {
          _kGooglePlex = CameraPosition(
            target: LatLng(
                double.parse(arguments["lat"]), double.parse(arguments["lng"])),
            zoom: 14.4746,
          );
        });
      }
    });
    // initialMap();
  }

  @override
  Widget build(BuildContext context) {
    ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    return Scaffold(
      // appBar: AppBar(
      //   iconTheme: IconThemeData(color: Colors.black),
      //   elevation: 0,
      //   backgroundColor: Colors.white,
      // ),
      body: ListView(
        children: [
          Stack(
            children: [
              args[(_foto == 'Alat'
                              ? "foto_alat_produksi"
                              : "foto_ruang_produksi")] ==
                          "" ||
                      args[(_foto == 'Alat'
                              ? "foto_alat_produksi"
                              : "foto_ruang_produksi")] ==
                          null
                  ? Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          height: 200,
                          color: themeProvider.bgColor,
                        ),
                        Icon(Icons.image_outlined,
                            size: 24, color: Colors.grey.shade500)
                      ],
                    )
                  : Image.network(
                      _storageUrl +
                          args[(_foto == 'Alat'
                              ? "foto_alat_produksi"
                              : "foto_ruang_produksi")],
                      width: MediaQuery.of(context).size.width,
                      height: 200,
                      fit: BoxFit.fill,
                    ),
              Opacity(
                opacity: 0.3,
                child: Container(
                  color: Colors.black,
                  width: MediaQuery.of(context).size.width,
                  height: 200,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 150.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 6, horizontal: 14),
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              _foto == "Alat"
                                  ? Color(0xff46ACD5)
                                  : Colors.transparent,
                              _foto == "Alat"
                                  ? Color(0xFF4A0BFB)
                                  : Colors.transparent,
                            ],
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(22)),
                          border: Border.all(color: Colors.white)),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _foto = "Alat";
                          });
                        },
                        child: customText(
                            context,
                            Color(0xffffffff),
                            "Alat Produksi",
                            TextAlign.left,
                            14,
                            FontWeight.w700),
                      ),
                    ),
                    Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 6, horizontal: 14),
                      decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              _foto == "Ruang"
                                  ? Color(0xff46ACD5)
                                  : Colors.transparent,
                              _foto == "Ruang"
                                  ? Color(0xFF4A0BFB)
                                  : Colors.transparent,
                            ],
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(22)),
                          border: Border.all(color: Colors.white)),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _foto = "Ruang";
                          });
                        },
                        child: customText(
                            context,
                            Color(0xffffffff),
                            "Ruang Produksi",
                            TextAlign.left,
                            14,
                            FontWeight.w700),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10.0, top: 15),
            child: customText(context, Colors.black, args['nama_perusahaan'],
                TextAlign.left, 20, FontWeight.w700),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 10.0, top: 5),
            child: customText(context, Color(0xffBEAEAE), args['nama_pemilik'],
                TextAlign.left, 14, FontWeight.w500),
          ),
          args['id_cabang_industri'] == null
              ? Container()
              : Padding(
                  padding: const EdgeInsets.only(right: 10.0, top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      filterButton(
                          context,
                          convertIdCabangIndustri(args['id_cabang_industri']),
                          convertIdCabangIndustri(args['id_cabang_industri']),
                          () {})
                    ],
                  ),
                ),
          Padding(
            padding: const EdgeInsets.only(right: 10.0, top: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                GestureDetector(
                  onTap: () async {
                    String url =
                        "http://maps.google.com/maps?q=${args["lat"]},${args["lng"]}";
                    if (await canLaunch(url)) {
                      await launch(url);
                      return;
                    }
                    print("couldn't launch $url");
                  },
                  child: Column(
                    children: [
                      SvgPicture.asset(
                        "assets/images/map.svg",
                        width: 30,
                        height: 30,
                      ),
                      customText(context, Color(0xff909090), "Cek Lokasi",
                          TextAlign.left, 12, FontWeight.w400)
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () async {
                    String url =
                        "https://api.whatsapp.com/send?phone=62${args["nomor_telpon"].toString().substring(1, args["nomor_telpon"].length)}";
                    if (await canLaunch(url)) {
                      await launch(url);
                      return;
                    }
                    print("couldn't launch $url");
                  },
                  child: Column(
                    children: [
                      SvgPicture.asset(
                        "assets/images/smartphone.svg",
                        width: 30,
                        height: 30,
                      ),
                      customText(context, Color(0xff909090), "Hubungi UMKM",
                          TextAlign.left, 12, FontWeight.w400)
                    ],
                  ),
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 14.0, top: 20),
            child: customText(context, Colors.black, "Details", TextAlign.left,
                15, FontWeight.w400),
          ),
          listLabel2(
              context, "Bentuk Badan Usaha : ${args['bentuk_badan_usaha']}"),
          listLabel2(context,
              "Tahun Berdiri Badan Usaha : ${args['tahun_badan_usaha']}"),
          listLabel2(
              context, "Kapasitas Produksi : ${args['kapasitas_produksi']}"),
          listLabel2(context, "Satuan Produksi : ${args['satuan_produksi']}"),
          listLabel2(context, "Nilai Investasi : ${args['nilai_produksi']}"),
          listLabel2(context,
              "Nilai Bahan Baku / Bahan Penolong : ${args['nilai_bb_bp']}"),
          listLabel2(context, "Alamat : ${args['alamat']}"),
        ],
      ),
    );
  }
}
