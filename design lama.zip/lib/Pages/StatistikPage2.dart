import 'dart:convert';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/DropDown3Style2.dart';
import 'package:appsimanis/Widget/Dropdown2.dart';
import 'package:appsimanis/Widget/Dropdown2Style2.dart';
import 'package:appsimanis/Widget/Dropdown3.dart';
import 'package:appsimanis/Widget/EditDialogBox.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_svg/svg.dart';

class StatistikPage2 extends StatefulWidget {
  const StatistikPage2({Key? key}) : super(key: key);

  @override
  _StatistikPage2State createState() => _StatistikPage2State();
}

class _StatistikPage2State extends State<StatistikPage2> {
  int touchedIndex = -1;
  List _dataPieChart = [0, 0];
  List _dataPieChart2 = [0, 0];
  Object? args = {};
  String? _nilaiInvestasiFilter;
  String? _cabangIndustriFilter;
  bool? _sertifikatHalal = false;
  String? _sertifikatHalalFilter;
  bool? _sertifikatHaki = false;
  String? _sertifikatHakiFilter;
  bool? _sertifikatSNI = false;
  String? _sertifikatSNIFilter;

  List _klarifikasiIKM = [
    'Industri Kecil (< Rp.1.000.000.000)',
    'Industri Menengah (Rp.1.000.000.000 - Rp.15.000.000.000)',
    'Industri Besar (> Rp.15.000.000.000)'
  ];
  List _cabangIndustri = [];

  setData() {
    crud
        .getData(
            "/badan_usaha/statistik/totalTenagaKerja/klasifikasiFilter/$_nilaiInvestasiFilter/$_cabangIndustriFilter")
        .then((res) {
      setState(() {
        _dataPieChart[0] = jsonDecode(res.body)[0]["totalIKM"] == null
            ? 0
            : int.parse(jsonDecode(res.body)[0]["totalIKM"].toString());
        _dataPieChart[1] = jsonDecode(res.body)[0]["tenagaKerja"] == null
            ? 0
            : int.parse(jsonDecode(res.body)[0]["tenagaKerja"].toString());
      });
    });
  }

  setDataSertifikat() {
    if (_sertifikatHalalFilter == "null" &&
        _sertifikatHakiFilter == "null" &&
        _sertifikatSNIFilter == "null") {
      return 0;
    } else {
      print(
          "/badan_usaha/statistik/totalTenagaKerja/sertifikatFilter/$_sertifikatHalalFilter/$_sertifikatHakiFilter/$_sertifikatSNIFilter");
      crud
          .getData(
              "/badan_usaha/statistik/totalTenagaKerja/sertifikatFilter/$_sertifikatHalalFilter/$_sertifikatHakiFilter/$_sertifikatSNIFilter")
          .then((res) {
        print(res.body);
        List _dataRes = jsonDecode(res.body);
        print(_dataRes.length == 0);
        int _totalTenagaKerja = 0;
        int _totalIkm = 0;
        // print("_totalTenagaKerja");
        // print(_totalTenagaKerja);
        // print(_dataRes);
        // print(_dataRes[0]['male']);
        // print(_dataRes[0]['famale']);
        if (_dataRes.length == 0) {
          setState(() {
            _dataPieChart2[0] = 0;
            _dataPieChart2[1] = 0;
          });
        } else {
          for (var i = 0; i < _dataRes.length; i++) {
            var a = _dataRes[i]["male"] == null
                ? 0
                : int.parse(_dataRes[i]["male"].toString());
            var a1 = _dataRes[i]["totalIKM"] == null
                ? 0
                : int.parse(_dataRes[i]["totalIKM"].toString());
            var b = _dataRes[i]["famale"] == null
                ? 0
                : int.parse(_dataRes[i]["famale"].toString());

            var c = a + b;
            

            _totalTenagaKerja += c;
            _totalIkm += a1;
          }
          setState(() {
            _dataPieChart2[0] = _totalIkm == null
                ? 0
                : int.parse(_totalIkm.toString());
            _dataPieChart2[1] = _totalTenagaKerja == null
                ? 0
                : int.parse(_totalTenagaKerja.toString());
          });
        }
      });
    }
  }

  getCabangIndustri() {
    crud.getData("/cabang_industri").then((res) {
      setState(() {
        _cabangIndustri = jsonDecode(res.body);
      });
    });
  }

  @override
  void initState() {
    super.initState();
    getCabangIndustri();
    // setData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          // title: textLabel("Produk", 15, Colors.black, "", FontWeight.w400),
          centerTitle: true,

          iconTheme: IconThemeData(color: Colors.black),
          elevation: 0,
          backgroundColor: Colors.white,
        ),
        body: ListView(
          children: [
            dropDown2Style2(context, _nilaiInvestasiFilter, "Pilih",
                "Klarifikasi :", _klarifikasiIKM, (newValue) {
              setState(() {
                _nilaiInvestasiFilter = newValue!;
              });
              setData();
            }),
            dropDown3style2(context, _cabangIndustriFilter, 'nama', 'Pilih',
                'Sektor Industri', _cabangIndustri, (newValue) {
              setState(() {
                _cabangIndustriFilter = newValue!;
              });
              setData();
            }),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _nilaiInvestasiFilter = null;
                        _cabangIndustriFilter = null;
                      });
                    },
                    child: customText(context, Colors.black, 'Reset',
                        TextAlign.center, 14, FontWeight.w400),
                  )
                ],
              ),
            ),
            Card(
              elevation: 9,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  children: [
                    Expanded(
                      child: AspectRatio(
                        aspectRatio: 1.3,
                        child: PieChart(
                          PieChartData(
                              pieTouchData: PieTouchData(
                                  touchCallback: (pieTouchResponse) {
                                setState(() {
                                  final desiredTouch = pieTouchResponse
                                          .touchInput is! PointerExitEvent &&
                                      pieTouchResponse.touchInput
                                          is! PointerUpEvent;
                                  if (desiredTouch &&
                                      pieTouchResponse.touchedSection != null) {
                                    touchedIndex = pieTouchResponse
                                        .touchedSection!.touchedSectionIndex;
                                  } else {
                                    touchedIndex = -1;
                                  }
                                });
                              }),
                              borderData: FlBorderData(
                                show: false,
                              ),
                              sectionsSpace: 5,
                              centerSpaceRadius: 15,
                              sections: showingSections()),
                        ),
                      ),
                    ),
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const <Widget>[
                        Indicator(
                          color: Color(0xff41AAC9),
                          text: 'Total IKM',
                          isSquare: true,
                        ),
                        SizedBox(
                          height: 4,
                        ),
                        Indicator(
                          color: Color(0xff4930C5),
                          text: 'Tenaga Kerja',
                          isSquare: true,
                        ),
                        SizedBox(
                          height: 4,
                        ),
                        // Indicator(
                        //   color: Color(0xff845bef),
                        //   text: 'Third',
                        //   isSquare: true,
                        // ),
                        // SizedBox(
                        //   height: 4,
                        // ),
                        // Indicator(
                        //   color: Color(0xff13d38e),
                        //   text: 'Fourth',
                        //   isSquare: true,
                        // ),
                        // SizedBox(
                        //   height: 18,
                        // ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              // height: 100,
              child: CheckboxListTile(
                  title: Text('Sertifikat Halal :'),
                  value: _sertifikatHalal,
                  onChanged: (val) {
                    setState(() {
                      _sertifikatHalal = val;
                      val == null
                          ? _sertifikatHalalFilter = "null"
                          : val
                              ? _sertifikatHalalFilter = "{}"
                              : _sertifikatHalalFilter = "null";
                    });
                    setDataSertifikat();
                  }),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              // height: 100,
              child: CheckboxListTile(
                  title: Text('Sertifikat HaKi :'),
                  value: _sertifikatHaki,
                  onChanged: (val) {
                    setState(() {
                      _sertifikatHaki = val;
                      val == null
                          ? _sertifikatHakiFilter = "null"
                          : val
                              ? _sertifikatHakiFilter = "{}"
                              : _sertifikatHakiFilter = "null";
                    });
                    setDataSertifikat();
                  }),
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              // height: 100,
              child: CheckboxListTile(
                  title: Text('Sertifikat SNI :'),
                  value: _sertifikatSNI,
                  onChanged: (val) {
                    setState(() {
                      _sertifikatSNI = val;
                      val == null
                          ? _sertifikatSNIFilter = "null"
                          : val
                              ? _sertifikatSNIFilter = "{}"
                              : _sertifikatSNIFilter = "null";
                    });
                    setDataSertifikat();
                  }),
            ),
            SizedBox(
              width: 300,
              height: 200,
              child: Card(
                elevation: 9,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: AspectRatio(
                          aspectRatio: 1.3,
                          child: PieChart(
                            PieChartData(
                                pieTouchData: PieTouchData(
                                    touchCallback: (pieTouchResponse) {
                                  setState(() {
                                    final desiredTouch = pieTouchResponse
                                            .touchInput is! PointerExitEvent &&
                                        pieTouchResponse.touchInput
                                            is! PointerUpEvent;
                                    if (desiredTouch &&
                                        pieTouchResponse.touchedSection !=
                                            null) {
                                      touchedIndex = pieTouchResponse
                                          .touchedSection!.touchedSectionIndex;
                                    } else {
                                      touchedIndex = -1;
                                    }
                                  });
                                }),
                                borderData: FlBorderData(
                                  show: false,
                                ),
                                sectionsSpace: 5,
                                centerSpaceRadius: 15,
                                sections: showingSections2()),
                          ),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const <Widget>[
                          Indicator(
                            color: Color(0xff41AAC9),
                            text: 'Total IKM',
                            isSquare: true,
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Indicator(
                            color: Color(0xff4930C5),
                            text: 'Tenaga Kerja',
                            isSquare: true,
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          // Indicator(
                          //   color: Color(0xff845bef),
                          //   text: 'Third',
                          //   isSquare: true,
                          // ),
                          // SizedBox(
                          //   height: 4,
                          // ),
                          // Indicator(
                          //   color: Color(0xff13d38e),
                          //   text: 'Fourth',
                          //   isSquare: true,
                          // ),
                          // SizedBox(
                          //   height: 18,
                          // ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  List<PieChartSectionData> showingSections() {
    return List.generate(2, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      final widgetSize = isTouched ? 65.0 : 40.0;
      switch (i) {
        case 0:
          return PieChartSectionData(
            color: const Color(0xff41AAC9),
            value: _dataPieChart[0].toDouble(),
            title: '${_dataPieChart[0]}',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: const Color(0xffffffff)),
            badgeWidget: _Badge(
              'assets/images/UMKMIcon.svg',
              size: widgetSize,
              borderColor: const Color(0xff41AAC9),
            ),
            badgePositionPercentageOffset: 1.29,
          );
        case 1:
          return PieChartSectionData(
            color: const Color(0xff4930C5),
            value: _dataPieChart[1].toDouble(),
            title: '${_dataPieChart[1]}',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: const Color(0xffffffff)),
            badgeWidget: _Badge(
              'assets/images/tenagaKerjaIcon.svg',
              size: widgetSize,
              borderColor: const Color(0xff4930C5),
            ),
            badgePositionPercentageOffset: 1.29,
          );
        // case 2:
        //   return PieChartSectionData(
        //     color: const Color(0xff845bef),
        //     value: 15,
        //     title: '15%',
        //     radius: radius,
        //     titleStyle: TextStyle(
        //         fontSize: fontSize,
        //         fontWeight: FontWeight.bold,
        //         color: const Color(0xffffffff)),
        //   );
        // case 3:
        //   return PieChartSectionData(
        //     color: const Color(0xff13d38e),
        //     value: 15,
        //     title: '15%',
        //     radius: radius,
        //     titleStyle: TextStyle(
        //         fontSize: fontSize,
        //         fontWeight: FontWeight.bold,
        //         color: const Color(0xffffffff)),
        //   );
        default:
          throw Error();
      }
    });
  }

  List<PieChartSectionData> showingSections2() {
    return List.generate(2, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      final widgetSize = isTouched ? 65.0 : 40.0;
      switch (i) {
        case 0:
          return PieChartSectionData(
            color: const Color(0xff41AAC9),
            value: _dataPieChart2[0].toDouble(),
            title: '${_dataPieChart2[0]}',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: const Color(0xffffffff)),
            badgeWidget: _Badge(
              'assets/images/UMKMIcon.svg',
              size: widgetSize,
              borderColor: const Color(0xff41AAC9),
            ),
            badgePositionPercentageOffset: 1.29,
          );
        case 1:
          return PieChartSectionData(
            color: const Color(0xff4930C5),
            value: _dataPieChart2[1].toDouble(),
            title: '${_dataPieChart2[1]}',
            radius: radius,
            titleStyle: TextStyle(
                fontSize: fontSize,
                fontWeight: FontWeight.bold,
                color: const Color(0xffffffff)),
            badgeWidget: _Badge(
              'assets/images/tenagaKerjaIcon.svg',
              size: widgetSize,
              borderColor: const Color(0xff4930C5),
            ),
            badgePositionPercentageOffset: 1.29,
          );
        // case 2:
        //   return PieChartSectionData(
        //     color: const Color(0xff845bef),
        //     value: 15,
        //     title: '15%',
        //     radius: radius,
        //     titleStyle: TextStyle(
        //         fontSize: fontSize,
        //         fontWeight: FontWeight.bold,
        //         color: const Color(0xffffffff)),
        //   );
        // case 3:
        //   return PieChartSectionData(
        //     color: const Color(0xff13d38e),
        //     value: 15,
        //     title: '15%',
        //     radius: radius,
        //     titleStyle: TextStyle(
        //         fontSize: fontSize,
        //         fontWeight: FontWeight.bold,
        //         color: const Color(0xffffffff)),
        //   );
        default:
          throw Error();
      }
    });
  }
}

class Indicator extends StatelessWidget {
  final Color color;
  final String text;
  final bool isSquare;
  final double size;
  final Color textColor;

  const Indicator({
    Key? key,
    required this.color,
    required this.text,
    required this.isSquare,
    this.size = 16,
    this.textColor = const Color(0xff505050),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: isSquare ? BoxShape.rectangle : BoxShape.circle,
            color: color,
          ),
        ),
        const SizedBox(
          width: 4,
        ),
        Text(
          text,
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: textColor),
        )
      ],
    );
  }
}

class _Badge extends StatelessWidget {
  final String svgAsset;
  final double size;
  final Color borderColor;

  const _Badge(
    this.svgAsset, {
    Key? key,
    required this.size,
    required this.borderColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: PieChart.defaultDuration,
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(
          color: borderColor,
          width: 2,
        ),
        boxShadow: <BoxShadow>[
          BoxShadow(
            color: Colors.black.withOpacity(.5),
            offset: const Offset(3, 3),
            blurRadius: 3,
          ),
        ],
      ),
      padding: EdgeInsets.all(size * .15),
      child: Center(
        child: SvgPicture.asset(
          svgAsset,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
