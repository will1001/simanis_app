import 'dart:async';
import 'dart:convert';

import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:appsimanis/Widget/ButtonGradient1.dart';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/EditDialogBox.dart';
import 'package:appsimanis/Widget/TextLabel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

class DetailsProduk extends StatefulWidget {
  const DetailsProduk({Key? key}) : super(key: key);

  @override
  _DetailsProdukState createState() => _DetailsProdukState();
}

class _DetailsProdukState extends State<DetailsProduk> {
  var args;
  List<Marker> allMarkers = [];
  List _listcabangIndustri = [];
  Completer<GoogleMapController> _controller = Completer();
  var _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  String _storageUrl = "https://simanis.ntbprov.go.id/storage/";

  getCabangIndustri(String id) {
    crud.getData("/cabang_industri/$id").then((res) {
      setState(() {
        _listcabangIndustri.addAll(jsonDecode(res.body));
      });
    });
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      var arguments = (ModalRoute.of(context)!.settings.arguments as Map);
      setState(() {
        args = arguments;
      });
      if (arguments["lat"] != null && arguments["lng"] != null) {
        setState(() {
          _kGooglePlex = CameraPosition(
            target: LatLng(
                double.parse(arguments["lat"]), double.parse(arguments["lng"])),
            zoom: 14.4746,
          );
        });
      }
      getCabangIndustri(arguments["id_cabang_industri"]);
    });
  }

  dateFormat(String date) {
    final DateFormat formatter = DateFormat('dd MMM yyyy');
    final String formatted = formatter.format(DateTime.parse(date));
    return formatted;
  }

  @override
  Widget build(BuildContext context) {
    ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    return Scaffold(
      body: ListView(
        children: [
          Stack(
            alignment: Alignment.topCenter,
            children: [
              Image.network(
                _storageUrl + args["foto"],
                height: 250,
                width: MediaQuery.of(context).size.width,
                fit: BoxFit.fill,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 186.0),
                child: Card(
                  elevation: 9,
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(11)),
                    width: 276,
                    height: 141,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 22, horizontal: 17),
                      child: Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          ListView(
                            // crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              customText(context, Colors.black, args['nama'],
                                  TextAlign.left, 22, FontWeight.w700),
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: customText(
                                    context,
                                    Color(0xff958C8C),
                                    args['nama_pemilik'],
                                    TextAlign.left,
                                    15,
                                    FontWeight.w500),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(right: 18.0),
                                  child: GestureDetector(
                                    onTap: () async {
                                      String url =
                                          "http://maps.google.com/maps?q=${args["lat"]},${args["lng"]}";
                                      if (await canLaunch(url)) {
                                        await launch(url);
                                        return;
                                      }
                                      print("couldn't launch $url");
                                    },
                                    child: SvgPicture.asset(
                                      "assets/images/map.svg",
                                      width: 30,
                                      height: 30,
                                    ),
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () async {
                                    String url =
                                        "https://api.whatsapp.com/send?phone=62${args["nomor_telpon"].toString().substring(1, args["nomor_telpon"].length)}";
                                    if (await canLaunch(url)) {
                                      await launch(url);
                                      return;
                                    }
                                    print("couldn't launch $url");
                                  },
                                  child: SvgPicture.asset(
                                    "assets/images/smartphone.svg",
                                    width: 30,
                                    height: 30,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0, top: 10),
            child: customText(context, Colors.black, "Deskripsi",
                TextAlign.left, 21, FontWeight.w700),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0, top: 8),
            child: customText(context, Color(0xff909090), args['deskripsi'],
                TextAlign.left, 15, FontWeight.w400),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0, top: 10),
            child: customText(context, Colors.black, "Profil Badan Usaha",
                TextAlign.left, 21, FontWeight.w700),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15.0, top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 155,
                  height: 30,
                  child: ButtonGradient1(
                      context, "Lihat Profil Badan Usaha", 10, () {
                    Navigator.pushNamed(context, "/detailsUMKM",
                        arguments: args);
                  }),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
