import 'dart:convert';

import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:appsimanis/Widget/Button1.dart';
import 'package:appsimanis/Widget/ButtonGradient1.dart';
import 'package:appsimanis/Widget/CardUMKM.dart';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/DropDown3Style2.dart';
import 'package:appsimanis/Widget/DropDownString.dart';
import 'package:appsimanis/Widget/Dropdown2Style2.dart';
import 'package:appsimanis/Widget/Dropdown3.dart';
import 'package:appsimanis/Widget/EditDialogBox.dart';
import 'package:appsimanis/Widget/FilterButton.dart';
import 'package:appsimanis/Widget/FilterDrawer.dart';
import 'package:appsimanis/Widget/GradientBg.dart';
import 'package:appsimanis/Widget/LoadingWidget.dart';
import 'package:appsimanis/Widget/SearchButton1.dart';
import 'package:appsimanis/Widget/SearchInput.dart';
import 'package:appsimanis/Widget/TextLabel.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

class ListDataIKM extends StatefulWidget {
  const ListDataIKM({Key? key}) : super(key: key);

  @override
  _ListDataIKMState createState() => _ListDataIKMState();
}

class _ListDataIKMState extends State<ListDataIKM> {
  final globalKey = GlobalKey<ScaffoldState>();
  ScrollController _scrollController = new ScrollController();

  List _listBadanUsaha = [];
  String? _kabupaten = null;
  String? _kecamatan = null;
  String? _kelurahan = null;
  String _lat = "";
  String _lng = "";
  List _listKabupaten = [];
  List _listKecamatan = [];
  List _listKelurahan = [];
  List _listCabangIndustri = [];
  List _listBadanUsahaNotNullFoto = [];
  bool _loading = true;
  bool _filterTerdekat = false;
  Object? args = {};
  int _dataLoaded = 0;
  String _iDkategori = "Semua";
  TextEditingController _keywordController = new TextEditingController();

  var HeadTable = [
    "No",
    "Nama Perusahaan",
    'Nama Pemilik',
    'Alamat',
    'Status Verifikasi',
    'Nomor Telepon',
    // 'male',
    // 'famale',
    // 'nilai_investasi',
    // 'kapasitas_produksi',
  ];

  getBadanUsahaFilter(
      String? _idCabangIndustri,
      String status,
      String? idKabupaten,
      String? idKecamatan,
      String? idKelurahan,
      int _limit) {
    // print(
    //     "/badan_usaha/filter/$status/$_limit/$_idCabangIndustri/$idKabupaten/$idKecamatan/$idKelurahan");

    switch (_idCabangIndustri) {
      case "Semua":
        _idCabangIndustri = null;
        break;
      case "Pangan":
        _idCabangIndustri = "006c4210-7806-11eb-9b1b-81d2fad81425";
        break;
      case "Hulu Agro":
        _idCabangIndustri = "006d2610-7806-11eb-ab4c-a1abd6abcd37";
        break;
      case "Permesinan, Alat Transportasi & Energi Terbarukan":
        _idCabangIndustri = "006d8f20-7806-11eb-9444-bd238317ed47";
        break;
      case "Hasil Pertambangan":
        _idCabangIndustri = "006e3bd0-7806-11eb-a766-e1c38c7e931e";
        break;
      case "Ekonomi Kreatif":
        _idCabangIndustri = "006f3b70-7806-11eb-ae50-d1725dc37289";
        break;
      case "Kimia , Farmasi, Kosmetik & Kesehatan":
        _idCabangIndustri = "006eb850-7806-11eb-87a5-6fa3dfe46649";
        break;
      default:
    }
    if (_limit == 10) {
      _listBadanUsaha.clear();
    }
    crud
        .getData(
            "/badan_usaha/filter/$status/$_limit/$_idCabangIndustri/$idKabupaten/$idKecamatan/$idKelurahan")
        .then((res) {
      // print(jsonDecode(res.body));
      setState(() {
        _listBadanUsaha.addAll(jsonDecode(res.body));
        _listBadanUsahaNotNullFoto = jsonDecode(res.body)
            .where((el) =>
                el["foto_alat_produksi"] != null &&
                el["foto_alat_produksi"] != "")
            .toList();
        _loading = false;
        _dataLoaded = _limit;
      });
    });
  }

  cariBadanUsaha(String keyword) {
    // print("keyword");
    // print(keyword);
    if (keyword == "") {
      getBadanUsaha(10, args.toString());
    } else {
      crud.getData("/badan_usaha/cari/$keyword").then((res) {
        setState(() {
          _listBadanUsaha.clear();
          _listBadanUsaha.addAll(jsonDecode(res.body));
          _listBadanUsahaNotNullFoto = jsonDecode(res.body)
              .where((el) =>
                  el["foto_alat_produksi"] != null &&
                  el["foto_alat_produksi"] != "")
              .toList();
          _loading = false;
          // _keywordController.text = "";
        });
      });
    }
  }

  // getBadanUsaha() {
  //   crud.getData("/badan_usaha/limit/10").then((res) {
  //     // print(jsonDecode(res.body));
  //     setState(() {
  //       _listBadanUsaha = jsonDecode(res.body);
  //       _loading = false;
  //     });
  //   });
  // }

  getBadanUsaha(int _limit, String status) {
    crud.getData("/badan_usaha/limit/$_limit/$status").then((res) {
      // print(res.body);
      setState(() {
        if (_limit == 10) {
          _listBadanUsaha.clear();
        }
        _listBadanUsaha.addAll(jsonDecode(res.body));
        _listBadanUsahaNotNullFoto = jsonDecode(res.body)
            .where((el) =>
                el["foto_alat_produksi"] != null &&
                el["foto_alat_produksi"] != "")
            .toList();
        _loading = false;
        _dataLoaded = _limit;
      });
    });
  }

  getBadanUsahaTerdekat(int _limit, String lat, String lng, String status) {
    print("/badan_usaha/terdekat/$lat/$lng/$_limit/$status");
    crud.getData("/badan_usaha/terdekat/$lat/$lng/$_limit/$status").then((res) {
      setState(() {
        if (_limit == 10) {
          _listBadanUsaha.clear();
          _loading = true;
        }
        _listBadanUsaha.addAll(jsonDecode(res.body));
        _listBadanUsahaNotNullFoto = jsonDecode(res.body)
            .where((el) =>
                el["foto_alat_produksi"] != null &&
                el["foto_alat_produksi"] != "")
            .toList();
        _loading = false;
        _dataLoaded = _limit;
      });
    });
  }

  getCabangIndsutri() {
    crud.getData("/cabang_industri").then((res) {
      setState(() {
        _listCabangIndustri.add({'id': '212', 'nama': 'Semua'});
        _listCabangIndustri.addAll(jsonDecode(res.body));
        getBadanUsaha(10, args.toString());
      });
    });
  }

  getLatLng(int _limit) async {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    setState(() {
      _lat = position.latitude.toString();
      _lng = position.longitude.toString();
      _filterTerdekat = true;
    });
    getBadanUsahaTerdekat(_limit, position.latitude.toString(),
        position.longitude.toString(), args.toString());
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) async {
      final Object? arguments = (ModalRoute.of(context)!.settings.arguments
              as Map)["status_verifikasi"]
          .toString();
      setState(() {
        args = arguments;
      });
      getBadanUsaha(10, arguments.toString());
    });
    getCabangIndsutri();
    crud.getData("/provinsi/52/kabupaten").then((data) {
      // print(jsonDecode(data.body));
      setState(() {
        _listKabupaten = jsonDecode(data.body);
      });
    });
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        print("object");
        if (_iDkategori == "Semua" &&
            _kabupaten == null &&
            _kecamatan == null &&
            _kelurahan == null &&
            !_filterTerdekat) {
          getBadanUsaha(_dataLoaded + 10, args.toString());
        } else if (_filterTerdekat) {
          getLatLng(_dataLoaded + 10);
        } else {
          getBadanUsahaFilter(_iDkategori, args.toString(), _kabupaten,
              _kecamatan, _kelurahan, _dataLoaded + 10);
        }
      }
    });
  }

  clearFilter() {
    setState(() {
      _iDkategori = "Semua";
      _kabupaten = null;
      _kecamatan = null;
      _kelurahan = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    List<Widget> filterWidget = [
      customText(context, Colors.black, "Filters", TextAlign.left, 21,
          FontWeight.w700),

      Padding(
        padding: const EdgeInsets.only(top: 30.0),
        child: customText(context, Colors.black, "Sektor Industri",
            TextAlign.left, 14, FontWeight.w500),
      ),

      Padding(
        padding: const EdgeInsets.only(top: 20.0, bottom: 15),
        child: Row(
          children: [
            filterButton(context, 'Semua', _iDkategori, () {
              setState(() {
                _iDkategori = "Semua";
              });
            }),
            filterButton(context, 'Pangan', _iDkategori, () {
              setState(() {
                _iDkategori = "Pangan";
              });
            }),
            filterButton(context, 'Hulu Agro', _iDkategori, () {
              setState(() {
                _iDkategori = "Hulu Agro";
              });
            }),
          ],
        ),
      ),
      filterButton(context, 'Permesinan, Alat Transportasi & Energi Terbarukan',
          _iDkategori, () {
        setState(() {
          _iDkategori = "Permesinan, Alat Transportasi & Energi Terbarukan";
        });
      }),
      Padding(
        padding: const EdgeInsets.only(top: 15.0, bottom: 15),
        child: Row(
          children: [
            filterButton(context, 'Hasil Pertambangan', _iDkategori, () {
              setState(() {
                _iDkategori = "Hasil Pertambangan";
              });
            }),
            filterButton(context, 'Ekonomi Kreatif', _iDkategori, () {
              setState(() {
                _iDkategori = "Ekonomi Kreatif";
              });
            }),
          ],
        ),
      ),

      filterButton(
          context, 'Kimia , Farmasi, Kosmetik & Kesehatan', _iDkategori, () {
        setState(() {
          _iDkategori = "Kimia , Farmasi, Kosmetik & Kesehatan";
        });
      }),

      // dropDown3(_iDkategori, "nama", "Cabang Industri", _listCabangIndustri,
      //     (newValue) {
      //   setState(() {
      //     _iDkategori = newValue!;
      //     // setState(() {
      //     //   _loading = true;
      //     // });
      //     // if (newValue == '212') {
      //     //   getBadanUsaha(10, args.toString());
      //     // } else {
      //     //   getBadanUsahaFilter(_iDkategori, args.toString(), _kabupaten,
      //     //       _kecamatan, _kelurahan, 10);
      //     // }
      //   });
      // }),
      // dropDownString(_kabupaten, 'Kabupaten', _listKabupaten, (newValue) {
      //   // getBadanUsahaFilter(
      //   //     _iDkategori, args.toString(), newValue, null, null, 10);
      //   crud.getData("/kabupaten/" + newValue + "/kecamatan").then((data) {
      //     setState(() {
      //       // _loading = true;
      //       _kecamatan = null;
      //       _kelurahan = null;
      //       _listKecamatan.clear();
      //       _listKelurahan.clear();
      //       _listKecamatan = jsonDecode(data.body);
      //       _kabupaten = newValue;
      //     });
      //   });
      // }),
      Padding(
        padding: const EdgeInsets.only(top: 20.0),
        child: dropDown3style2(
            context, _kabupaten, 'name', 'Pilih', 'Kabupaten :', _listKabupaten,
            (newValue) {
          // getBadanUsahaFilter(
          //     _iDkategori, args.toString(), newValue, null, null, 10);
          crud.getData("/kabupaten/" + newValue + "/kecamatan").then((data) {
            setState(() {
              // _loading = true;
              _kecamatan = null;
              _kelurahan = null;
              _listKecamatan.clear();
              _listKelurahan.clear();
              _listKecamatan = jsonDecode(data.body);
              _kabupaten = newValue;
            });
          });
        }),
      ),
      Padding(
        padding: const EdgeInsets.only(top: 6.0),
        child: dropDown3style2(
            context, _kecamatan, 'name', 'Pilih', 'Kecamatan :', _listKecamatan,
            (newValue) {
          // getBadanUsahaFilter(
          //     _iDkategori, args.toString(), _kabupaten, newValue, null, 10);
          crud.getData("/kecamatan/" + newValue + "/kelurahan").then((data) {
            setState(() {
              // _loading = true;
              _kelurahan = null;
              _listKelurahan.clear();
              _listKelurahan = jsonDecode(data.body);
              _kecamatan = newValue;
            });
          });
        }),
      ),

      Padding(
        padding: const EdgeInsets.only(top: 6.0),
        child: dropDown3style2(
            context, _kelurahan, 'name', 'Pilih', 'Kelurahan :', _listKelurahan,
            (newValue) {
          // getBadanUsahaFilter(
          //     _iDkategori, args.toString(), _kabupaten, _kecamatan, newValue, 10);
          setState(() {
            // _loading = true;
            _kelurahan = newValue;
          });
        }),
      ),
      // Text(_listKabupaten[0].toString()),
      // dropDownString(_kecamatan, 'Kecamatan', _listKecamatan, (newValue) {
      //   // getBadanUsahaFilter(
      //   //     _iDkategori, args.toString(), _kabupaten, newValue, null, 10);
      //   crud.getData("/kecamatan/" + newValue + "/kelurahan").then((data) {
      //     setState(() {
      //       // _loading = true;
      //       _kelurahan = null;
      //       _listKelurahan.clear();
      //       _listKelurahan = jsonDecode(data.body);
      //       _kecamatan = newValue;
      //     });
      //   });
      // }),

      // dropDownString(_kelurahan, 'Kelurahan', _listKelurahan, (newValue) {
      //   // getBadanUsahaFilter(
      //   //     _iDkategori, args.toString(), _kabupaten, _kecamatan, newValue, 10);
      //   setState(() {
      //     // _loading = true;
      //     _kelurahan = newValue;
      //   });
      // }),

      // button1("Terapkan filter", themeProvider.buttonColor, context, () {
      //   setState(() {
      //     _loading = true;
      //     _filterTerdekat = false;
      //   });
      //   if (_iDkategori == null &&
      //       _kabupaten == null &&
      //       _kecamatan == null &&
      //       _kelurahan == null) {
      //     getBadanUsaha(10, args.toString());
      //   } else {
      //     getBadanUsahaFilter(_iDkategori, args.toString(), _kabupaten,
      //         _kecamatan, _kelurahan, 10);
      //   }
      // }),
      Padding(
        padding: const EdgeInsets.only(top: 30.0),
        child: ButtonGradient1(context, 'Terapkan', 10, () {
          setState(() {
            _loading = true;
            _filterTerdekat = false;
          });
          if (_iDkategori == "Semua" &&
              _kabupaten == null &&
              _kecamatan == null &&
              _kelurahan == null) {
            getBadanUsaha(10, args.toString());
            Navigator.pop(context);
          } else {
            getBadanUsahaFilter(_iDkategori, args.toString(), _kabupaten,
                _kecamatan, _kelurahan, 10);
            Navigator.pop(context);
          }
        }),
      ),
      Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
                onTap: () {
                  clearFilter();
                  getBadanUsahaFilter(
                      null, args.toString(), null, null, null, 10);
                },
                child: Text("Reset"))
          ],
        ),
      ),
    ];

    return Stack(
      alignment: Alignment.center,
      children: [
        Scaffold(
          key: globalKey,
          endDrawer: filterDrawer(context, filterWidget),
          // appBar: AppBar(
          //   actions: [
          //     Builder(
          //       builder: (context) => IconButton(
          //         icon: Icon(Icons.filter_alt_outlined),
          //         onPressed: () => Scaffold.of(context).openEndDrawer(),
          //         tooltip:
          //             MaterialLocalizations.of(context).openAppDrawerTooltip,
          //       ),
          //     ),
          //   ],
          //   leading: Opacity(
          //       opacity: 0,
          //       child: IconButton(onPressed: () {}, icon: Icon(Icons.ac_unit))),
          //   title:
          //       textLabel("Data UMKM", 15, Colors.black, "", FontWeight.w400),
          //   centerTitle: true,
          //   iconTheme: IconThemeData(color: Colors.black),
          //   elevation: 0,
          //   backgroundColor: Colors.white,
          // ),
          body: Stack(
            children: [
              Container(
                height: 170,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xff46ACD5),
                    Color(0xFF4A0BFB),
                  ],
                )),
                // child: ,
              ),
              Padding(
                padding: const EdgeInsets.only(top: 130.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(35)),
                  child: Container(
                    color: Colors.white,
                  ),
                ),
              ),
              // customText(context, Color(0xff46ACD5), "Data UMKM",
              //         TextAlign.left, 17, FontWeight.w700)
              ListView(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        SearchButton1(context, "Cari UMKM", _keywordController,
                            () {
                          setState(() {
                            _loading = true;
                          });
                          FocusScope.of(context).requestFocus(FocusNode());
                          cariBadanUsaha(_keywordController.text);
                        }, () {
                          _keywordController.text = "";
                          FocusScope.of(context).requestFocus(FocusNode());
                          setState(() {
                            _listBadanUsaha.clear();
                            _loading = true;
                          });
                          getBadanUsaha(10, args.toString());
                          clearFilter();
                        }),
                        Container(
                          padding:
                              EdgeInsets.symmetric(vertical: 6, horizontal: 14),
                          decoration: BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(22)),
                              border: Border.all(color: Colors.white)),
                          child: GestureDetector(
                            onTap: () {
                              clearFilter();
                              getLatLng(10);
                            },
                            child: customText(
                                context,
                                Color(0xffffffff),
                                "Cari UMKM Terdekat",
                                TextAlign.left,
                                14,
                                FontWeight.w700),
                          ),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 33.0, top: 50, right: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        customText(context, Colors.black, "List Data UMKM",
                            TextAlign.left, 17, FontWeight.w700),
                        IconButton(
                            onPressed: () =>
                                globalKey.currentState!.openEndDrawer(),
                            icon: Icon(Icons.menu))
                      ],
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 470,
                    child: ListView(
                      controller: _scrollController,
                      children: _listBadanUsaha.map((e) {
                        return cardUMKM(
                            context,
                            e["nama_perusahaan"],
                            e["nama_pemilik"],
                            "https://api.whatsapp.com/send?phone=62${e["nomor_telpon"] == null ? "" : e["nomor_telpon"].toString().substring(1, e["nomor_telpon"].length)}",
                            "http://maps.google.com/maps?q=${e["lat"]},${e["lng"]}",
                            e);
                      }).toList(),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        _loading ? loadingWidget(context) : Container()
      ],
    );
  }
}
