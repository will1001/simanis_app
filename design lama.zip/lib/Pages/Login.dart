import 'dart:convert';

import 'package:appsimanis/Model/CRUD.dart';
import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:appsimanis/Services/FunctionGroup.dart';
import 'package:appsimanis/Widget/AlertDialogBox.dart';
import 'package:appsimanis/Widget/Button1.dart';
import 'package:appsimanis/Widget/ButtonGradient1.dart';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/InputForm.dart';
import 'package:appsimanis/Widget/InputFormStyle2.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  CRUD crud = new CRUD();
  bool _loading = false;
  FunctionGroup functionGroup = new FunctionGroup();
  TextEditingController emailTextEditingController =
      new TextEditingController();
  TextEditingController passwordTextEditingController =
      new TextEditingController();

  @override
  void initState() {
    super.initState();
    setState(() {
      // emailTextEditingController.text = "wilirahmatm@gmail.com";
      // passwordTextEditingController.text = "wili123";
      // emailTextEditingController.text = "wilirahmatm@gmail.com";
      // passwordTextEditingController.text = "wili123";
    });
  }

  @override
  Widget build(BuildContext context) {
    ThemeProvider themeProvider =
        Provider.of<ThemeProvider>(context, listen: false);
    return Scaffold(
      body: Stack(
        alignment: Alignment.topCenter,
        children: [
          Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 222,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0xff46ACD5),
                    Color(0xFF4A0BFB),
                  ],
                )),
              ),
              Image.asset(
                "assets/images/logo2.png",
                width: 130,
                height: 130,
              )
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 175.0),
            child: Card(
              elevation: 9,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(9.0),
              ),
              child: Container(
                width: 311,
                height: 307,
                child: ListView(
                  children: [
                    Form(
                      key: _formKey,
                      child: Container(
                        width: 311,
                        height: 307,
                        child: ListView(
                          children: [
                            inputFormStyle2(
                                "assets/images/message.png",
                                'Masukan Email anda',
                                'Email',
                                "Email",
                                'Email Tidak Boleh Kosong',
                                emailTextEditingController,
                                false),
                            inputFormStyle2(
                                "assets/images/padlock.png",
                                'Masukan Password anda',
                                "text",
                                'Password',
                                'Password Tidak Boleh Kosong',
                                passwordTextEditingController,
                                true),
                            Padding(
                              padding: const EdgeInsets.all(25.0),
                              child: ButtonGradient1(context, 'Login', 14, () {
                                // Navigator.pushNamed(context, '/homeLayoutPage',
                                //     arguments: <String, dynamic>{"selectedIndex": 3});
                                if (_formKey.currentState!.validate()) {
                                  Map<String, String> dataUsers = {
                                    "email": emailTextEditingController.text,
                                    "password":
                                        passwordTextEditingController.text,
                                  };
                                  crud.checkLogin(dataUsers).then((res) {
                                    String message =
                                        jsonDecode(res.body)["message"];
                                    if (res.statusCode == 201) {
                                      if (message == "data ada") {
                                        setState(() {
                                          _loading = true;
                                        });
                                        functionGroup.saveCache(dataUsers);
                                        Navigator.pushNamed(
                                            context, '/homeLayoutPage',
                                            arguments: <String, dynamic>{
                                              "selectedIndex": 3
                                            });
                                        setState(() {
                                          _loading = false;
                                        });
                                      } else {
                                        showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialogBox(
                                                  "alert", message, []);
                                            });
                                      }
                                    } else {
                                      print("error");
                                    }
                                  });
                                }
                              }),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Center(
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.pushNamed(context, '/daftar');
                                  },
                                  child: customText(
                                      context,
                                      Color(0xff4E4848),
                                      "Daftar",
                                      TextAlign.left,
                                      14,
                                      FontWeight.w700),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
