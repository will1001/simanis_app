import 'dart:convert';

import 'package:appsimanis/Model/CRUD.dart';
import 'package:appsimanis/Widget/AlertButton.dart';
import 'package:appsimanis/Widget/AlertDialogBox.dart';
import 'package:appsimanis/Widget/CardMenu.dart';
import 'package:appsimanis/Widget/CustomText.dart';
import 'package:appsimanis/Widget/GradientBg.dart';
import 'package:appsimanis/Widget/DrawerMenu.dart';
import 'package:appsimanis/Widget/MenuCard.dart';
import 'package:appsimanis/Widget/TextLabel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MemberPage extends StatefulWidget {
  const MemberPage({Key? key}) : super(key: key);

  @override
  _MemberPageState createState() => _MemberPageState();
}

class _MemberPageState extends State<MemberPage> {
  late DateTime currentBackPressTime;
  Map _cache = {};
  CRUD crud = new CRUD();
  String? _nama;
  List _dataIKM = [];
  bool _loading = true;

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      // Fluttertoast.showToast(msg: exit_warning);
      return Future.value(false);
    }
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialogBox("", "Keluar dari App ?", [
            AlertButton("Ya", Colors.blue, null, () async {
              SystemNavigator.pop();
            }, context),
            AlertButton("tidak", Colors.blue, null, () {
              Navigator.pop(context);
            }, context),
          ]);
        });
    return Future.value(true);
  }

  setCache() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? email = prefs.getString('email');
    String? nama = prefs.getString('nama');
    String? idUser = prefs.getString('idUser');
    if (nama == "") {
      crud.getData("/usersEmail/${email}").then((res) async {
        // print(jsonDecode(res.body)[0]["nama"]);
        print(res.statusCode);
        if (res.statusCode == 200) {
          await prefs.setString('nama', jsonDecode(res.body)[0]["nama"] ?? "");
          await prefs.setString('idUser', jsonDecode(res.body)[0]["id"] ?? "");
          setState(() {
            _nama = jsonDecode(res.body)[0]["nama"];
          });
        }
      });
    }
    setState(() {
      _nama = nama;
    });
  }

  checkDataIKM() async {
    print("Asdaf");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? idUserCache = prefs.getString('idUser');
    crud.getData("/badan_usaha/$idUserCache").then((res) {
      print(res.statusCode);
      if (res.statusCode == 200) {
        if (jsonDecode(res.body).length != 0) {
          setState(() {
            _dataIKM = jsonDecode(res.body);
          });
        }
      }
    });
    _loading = false;
  }

  @override
  void initState() {
    super.initState();
    setCache();
    checkDataIKM();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        // drawer: drawerMenu(context),
        // appBar: AppBar(
        //   iconTheme: IconThemeData(color: Colors.black),
        //   elevation: 0,
        //   backgroundColor: Colors.white,
        // ),
        body: Stack(
          children: [
            Image.asset(
              "assets/images/pattern2.png",
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              fit: BoxFit.fill,
            ),
            ListView(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 13.0, top: 21),
                  child: customText(context, Color(0xff141515),
                      "Selamat Datang", TextAlign.left, 14, FontWeight.w500),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 13.0, top: 0),
                  child: customText(context, Color(0xff4960E8), "${_nama}",
                      TextAlign.left, 17, FontWeight.w700),
                ),
                Center(
                    child: menuCard(
                        context, "Profil", "assets/images/profilIcon.png", () {
                  Navigator.pushNamed(context, '/profilPage');
                })),
                Center(
                    child: menuCard(
                        context, "UMKM", "assets/images/UMKMIcon.png", () {
                  Navigator.pushNamed(context, '/informasiIKM');
                })),
                Center(
                    child: menuCard(
                        context, "Produk", "assets/images/ProdukIcon.png", () {
                  checkDataIKM();
                  if (_dataIKM.length == 0) {
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialogBox(
                              "Perhatian", "IKM Anda Belum Diverifikasi", []);
                        });
                  } else {
                    Navigator.pushNamed(context, '/produkPageMember',
                        arguments: {"data": _dataIKM});
                  }
                })),
                Center(
                    child: menuCard(
                        context, "Link Perbankan", "assets/images/BankIcon.png",
                        () {
                  Navigator.pushNamed(context, '/linkBank');
                })),
                Center(
                    child: menuCard(
                        context, "Log Out", "assets/images/LogoutIcon.png",
                        () async {
                  SharedPreferences preferences =
                      await SharedPreferences.getInstance();
                  await preferences.clear();
                  Navigator.pushNamed(context, '/homeLayoutPage');
                })),
              ],
            )
          ],
        ),
      ),
    );
  }
}
