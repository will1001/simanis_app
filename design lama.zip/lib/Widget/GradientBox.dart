// import 'package:flutter/material.dart';

// Widget gradientBox() {
//   return Container(
//             height: 170,
//             decoration: BoxDecoration(
//                 gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: [
//                 Color(0xff46ACD5),
//                 Color(0xFF4A0BFB),
//               ],
//             ));
// }
