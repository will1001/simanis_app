import 'package:appsimanis/Provider/ThemeProvider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

Widget SearchButton1(BuildContext context, String _hintText,
    TextEditingController _keywordController, var _onSearch, var _clearSearch) {
  ThemeProvider themeProvider =
      Provider.of<ThemeProvider>(context, listen: false);
  return Container(
    width: 150,
    height: 50,
    child: TextField(
        controller: _keywordController,
        style: TextStyle(color: Colors.white, fontSize: 13),
        decoration: InputDecoration(
            // border: InputBorder.none,
            hintStyle: TextStyle(color: Colors.white, fontSize: 13),
            hintText: _hintText,
            contentPadding: EdgeInsets.only(top: 17.0),
            enabledBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
            ),
            focusedBorder: UnderlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
            ),
            // suffixIcon: GestureDetector(
            //   onTap: _clearSearch,
            //   child: Icon(
            //     Icons.clear,
            //     size: 24,
            //     color: Colors.white,
            //   ),
            // ),
            prefixIcon: GestureDetector(
              onTap: _onSearch,
              child: Icon(
                Icons.search,
                size: 24,
                color: Colors.white,
              ),
            ))),
  );
}
